# VE482 Homework1 Ex.5

This is the README file for VE482 (Fall2021) Homwork1 Ex.5.

All the commands required by Ex.5 are listed in ex5.sh file, with comments telling which command corresponds to which question.